
public class Special extends Menu{
	public String SpecialNaration;
}
