
public class Restaurant {
	public String Name;
	int Romantic = 2;
	int General = 4;
	int Family = 10;
}
