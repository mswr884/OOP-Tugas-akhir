
public class Menu {
	public String MenuId;
	public String MenuName;
	int Price;
}
