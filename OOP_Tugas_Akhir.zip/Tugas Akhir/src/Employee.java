
public class Employee {
	String EmployeeID;
	String EmployeeName;
	String Cabang;
}
