
public class Local extends Menu{
	public String Place;
	public String LocalNaration;
}
